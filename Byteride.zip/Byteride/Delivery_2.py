import sqlite3
import re
from datetime import datetime

# Database initialization and table creation
conn = sqlite3.connect("byteride.db")
cursor = conn.cursor()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS riders (
        id INTEGER PRIMARY KEY,
        name TEXT,
        surname TEXT,
        payment_method TEXT,
        card_number TEXT,
        card_expiration TEXT,
        card_cvv TEXT,
        tip REAL
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS rides (
        id INTEGER PRIMARY KEY,
        rider_id INTEGER,
        from_location TEXT,
        to_location TEXT,
        distance REAL,
        ride_type TEXT,
        fare REAL,
        tip REAL,
        ride_date TEXT
    )
''')

conn.commit()

# Helper functions for card number, CVV, and card expiration validation
def is_valid_card_number(card_number):
    return re.match(r'^\d{16}$', card_number) is not None

def is_valid_card_expiration(card_expiration):
    return re.match(r'^(0[1-9]|1[0-2])/\d{2}$', card_expiration) is not None

def is_valid_cvv(cvv):
    return re.match(r'^\d{3}$', cvv) is not None

# Cities and townships
cities_and_townships = [
    "Cape Town", "Bellville", "Stellenbosch", "Somerset West", "Paarl",
    "Fish Hoek", "Muizenberg", "Simon's Town", "Durbanville", "Hout Bay",
    "Khayelitsha", "Gugulethu", "Langa", "Mitchells Plain", "Nyanga",
    "Philippi", "Delft", "Crossroads", "Kraaifontein", "Bonteheuwel"
]

# Define the initial rates and surcharge
base_rate = 25  # Default base rate
peak_charge_rate = 0.10  # Default peak charge rate (10%)
vat_rate = 0.15  # Default VAT rate (15%)
booking_fee = 5  # Default booking fee

# Function to calculate the fare for a ride
def calculate_fare(distance, ride_type):
    global base_rate, peak_charge_rate, vat_rate

    # Get the current South African time
    sa_timezone = pytz.timezone('Africa/Johannesburg')
    current_time = datetime.now(tz=sa_timezone)

    # Check if it's a weekday and time between 7:30 to 9:00 or 16:30 to 18:00
    is_peak_period = (
        current_time.weekday() < 5  # Monday to Friday
        and (
            (current_time.hour == 7 and current_time.minute >= 30)
            or (current_time.hour >= 8 and current_time.hour < 9)
            or (current_time.hour == 16 and current_time.minute >= 30)
            or (current_time.hour >= 17 and current_time.hour < 18)
        )
    )

    # Calculate the fare based on ride type
    if ride_type == "cheap":
        fare = distance * base_rate
    elif ride_type == "comfort":
        fare = distance * (base_rate + (base_rate * peak_charge_rate if is_peak_period else 0))
    elif ride_type == "luxury":
        fare = distance * (base_rate * 2)  # Double the base rate

    # Apply VAT
    fare_with_vat = fare * (1 + vat_rate)

    return fare_with_vat

# Menu display and user input with error handling
while True:
    print("\nByteRide Menu:")
    print("1. Rider Details - Register a rider")
    print("2. Book a Ride")
    print("3. Calculate the Fare")
    print("4. Calculate Driver's Tip")
    print("5. Update Rates")
    print("6. Driver Report")
    print("7. Quit")

    choice = input("Select an option: ")

    if choice == '1':
        # Rider registration
        name = input("Enter rider's name: ")
        surname = input("Enter rider's surname: ")
        payment_method = input("Enter payment method (cash or card): ")

        if payment_method == 'card':
            card_number = input("Enter card number (16 digits): ")
            card_expiration = input("Enter card expiration date (MM/YY): ")
            card_cvv = input("Enter card CVV (3 digits): ")

            if (
                not is_valid_card_number(card_number) or
                not is_valid_card_expiration(card_expiration) or
                not is_valid_cvv(card_cvv)
            ):
                print("Invalid card information. Please check card number, expiration date, and CVV.")
                continue

        else:
            card_number = card_expiration = card_cvv = ""

        cursor.execute("INSERT INTO riders (name, surname, payment_method, card_number, card_expiration, card_cvv, tip) VALUES (?, ?, ?, ?, ?, ?, ?)", (name, surname, payment_method, card_number, card_expiration, card_cvv, 0.0))
        conn.commit()
        print("Rider registered successfully!")

    elif choice == '2':
        # Book a ride with automatic distance calculation
        rider_id = int(input("Enter your rider ID: "))  # Assume the customer knows their rider ID

        # Check if the rider exists in the database
        cursor.execute("SELECT id, name FROM riders WHERE id = ?", (rider_id,))
        rider = cursor.fetchone()

        if rider is None:
            print("Rider not found. Please check your ID or register if you are a new rider.")
            continue

        try:
            print("Pickup Locations:")
            for i, location in enumerate(cities_and_townships):
                print(f"{i + 1}. {location}")

            from_location_index = int(input("Select pickup location by number: ")) - 1
            from_location = cities_and_townships[from_location_index]

            print("Drop-off Locations:")
            for i, location in enumerate(cities_and_townships):
                print(f"{i + 1}. {location}")

            to_location_index = int(input("Select drop-off location by number: ")) - 1
            to_location = cities_and_townships[to_location_index]

            # Automatically calculate the distance (for simplicity, we'll assume a flat rate per kilometer)
            distance = abs(from_location_index - to_location_index) * 2  # Example flat rate: R2 per kilometer

            ride_type = input("Enter ride type (cheap, comfort, luxury): ")

            tip = float(input("Enter tip amount (or 0 for no tip): "))

            # Calculate fare based on the provided formula
            total_fare = (base_rate + (distance * 2 * (1 + peak_charge_rate)) * (1 + vat_rate)) + booking_fee + tip

            # Insert the ride into the rides table
            cursor.execute("INSERT INTO rides (rider_id, from_location, to_location, distance, ride_type, fare, tip, ride_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        (rider_id, from_location, to_location, distance, ride_type, total_fare, tip, datetime.now().strftime("%Y-%m-%d")))
            conn.commit()

            # Display booking receipt to the client
            rider_name = rider[1]  # Get the name of the rider
            print(f"Booking Receipt for {rider_name}:")
            print(f"From: {from_location}")
            print(f"To: {to_location}")
            print(f"Distance: {distance} km")
            print(f"Ride Type: {ride_type}")
            print(f"Total Fare: R{total_fare:.2f}")
            print(f"Tip: R{tip:.2f}")

        except (ValueError, IndexError):
            print("Invalid input. Please enter valid numbers for location.")

    elif choice == '3':
    # Fare calculation
        for row in cursor.execute("SELECT distance, ride_type, tip FROM rides WHERE rider_id = ?", (rider_id,)):
            distance, ride_type, tip = row
            tip = tip if tip is not None else 0.0

            # Calculate fare based on the provided formula
            total_fare = calculate_fare(distance, ride_type) + booking_fee + tip
            print(f"Total Fare for {rider_name}: R{total_fare:.2f}")


        if not rides:
            print("No rides found for this rider.")
            continue

        rider_name = rider[1]  # Get the name of the rider
        total_fare = 0

        for row in rides:
            distance, ride_type, tip = row
            tip = tip if tip is not None else 0.0

            # Calculate fare based on the provided formula
            fare = (base_rate + (distance * 2 * (1 + peak_charge_rate)) * (1 + vat_rate)) + booking_fee + tip
            total_fare += fare

        print(f"Total Fare for {rider_name}: R{total_fare:.2f}")

    elif choice == '4':
        # Driver tipping
        rider_id = rider[0]
        tip = float(input("Enter tip amount (or 0 for no tip): "))
        cursor.execute("UPDATE rides SET tip = ? WHERE rider_id = ?", (tip, rider_id))
        conn.commit()
        print("Tip recorded successfully!")

    elif choice == '5':
        # Rate settings (Allow updates)
        base_rate = float(input(f"Enter new base rate (current: R{base_rate:.2f}): "))
        peak_charge_rate = float(input(f"Enter new peak charge rate (current: {peak_charge_rate * 100}%): "))
        vat_rate = float(input(f"Enter new VAT rate (current: {vat_rate * 100}%): "))
        booking_fee = float(input(f"Enter new booking fee (current: R{booking_fee:.2f}): "))
        print("Rate settings updated successfully!")

    elif choice == '6':
        from_date = input("Enter the from-date (YYYY-MM-DD, default is today): ")
        if not from_date:
            from_date = "2023-10-17"  # Replace with today's date or an appropriate default

        to_date = datetime.now().strftime("%Y-%m-%d")

        # Fetch all rider IDs
        cursor.execute("SELECT id FROM riders")
        all_rider_ids = cursor.fetchall()

        print("\nDriver Report for All Riders:")

        for rider_id in all_rider_ids:
            cursor.execute("SELECT name, surname FROM riders WHERE id = ?", (rider_id[0],))
            rider_info = cursor.fetchone()

            if rider_info is None:
                print(f"Rider ID {rider_id[0]} not found. Skipping.")
                continue

            cursor.execute("SELECT distance, ride_type, tip FROM rides WHERE rider_id = ? AND ride_date BETWEEN ? AND ?", (rider_id[0], from_date, to_date))
            rides = cursor.fetchall()

            # Initialize variables to calculate statistics
            total_distance = 0
            total_income = 0
            total_cash = 0
            total_card = 0
            num_rides = len(rides)

            for ride in rides:
                distance, ride_type, tip = ride
                tip = tip if tip is not None else 0.0

                # Calculate and accumulate statistics
                total_distance += distance
                ride_income = (base_rate + (distance * 2 * (1 + peak_charge_rate)) * (1 + vat_rate)) + booking_fee + tip
                total_income += ride_income

                if ride_type == "cheap":
                    total_cash += ride_income
                else:
                    total_card += ride_income

            average_distance = total_distance / num_rides if num_rides > 0 else 0  # Avoid division by zero
            average_income_per_km = total_income / total_distance if total_distance > 0 else 0  # Avoid division by zero
            percentage_cash = (total_cash / total_income) * 100 if total_income > 0 else 0  # Avoid division by zero
            percentage_card = (total_card / total_income) * 100 if total_income > 0 else 0  # Avoid division by zero

            # Display the calculated statistics for each rider
            print(f"\nDriver Report for {rider_info[0]} {rider_info[1]} (Rider ID {rider_id[0]}):")
            print("Number of rides:", num_rides)
            print(f"Total kilometers driven: {total_distance:.2f} km")
            print(f"Average kilometers per ride: {average_distance:.2f} km")
            print(f"Total income: R {total_income:.2f}")
            print(f"Average income per kilometer: R {average_income_per_km:.2f}/km")
            print(f"Split between charge rates (normal and peak): {percentage_cash:.2f}% / {percentage_card:.2f}%")
            print(f"Amount in cash: R {total_cash:.2f}")
            print(f"Percentage of earnings in cash: {percentage_cash:.2f}%")
            print(f"Amount earned on cards: R {total_card:.2f}")
            print(f"Percentage of earnings on cards: {percentage_card:.2f}%")

    elif choice == '7':
        # Quit the program
        print("Exiting ByteRide. Goodbye!")
        conn.close()
        break

    else:
        print("Invalid choice. Please select a valid option.")
