import sqlite3

# Database initialization and table creation
conn = sqlite3.connect("byteride.db")
cursor = conn.cursor()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS riders (
        id INTEGER PRIMARY KEY,
        name TEXT,
        surname TEXT,
        payment_method TEXT
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS rides (
        id INTEGER PRIMARY KEY,
        rider_id INTEGER,
        from_location TEXT,
        to_location TEXT,
        distance REAL,
        ride_type TEXT,
        fare REAL,
        peak_period_surcharge REAL
    )
''')

conn.commit()

# Cities and townships
cities_and_townships = [
    "Cape Town", "Bellville", "Stellenbosch", "Somerset West", "Paarl",
    "Fish Hoek", "Muizenberg", "Simon's Town", "Durbanville", "Hout Bay",
    "Khayelitsha", "Gugulethu", "Langa", "Mitchells Plain", "Nyanga",
    "Philippi", "Delft", "Crossroads", "Kraaifontein", "Bonteheuwel"
]

# Menu display and user input with error handling
while True:
    print("\nByteRide Menu:")
    print("1. Rider Details - Register a rider")
    print("2. Book a Ride")
    print("3. Calculate the Fare (Not implemented)")
    print("4. Calculate Driver's Tip (Not implemented)")
    print("5. Update Rates (Not implemented)")
    print("6. Driver Report (Not implemented)")
    print("7. Quit")

    choice = input("Select an option: ")

    if choice == '1':
        # Rider registration
        name = input("Enter rider's name: ")
        surname = input("Enter rider's surname: ")
        payment_method = input("Enter payment method (cash or card): ")

        cursor.execute("INSERT INTO riders (name, surname, payment_method) VALUES (?, ?, ?)", (name, surname, payment_method))
        conn.commit()
        print("Rider registered successfully!")

    elif choice == '2':
        # Book a ride with error handling
        try:
            print("Pickup Locations:")
            for i, location in enumerate(cities_and_townships):
                print(f"{i + 1}. {location}")

            from_location_index = int(input("Select pickup location by number: ")) - 1
            from_location = cities_and_townships[from_location_index]

            print("Drop-off Locations:")
            for i, location in enumerate(cities_and_townships):
                print(f"{i + 1}. {location}")

            to_location_index = int(input("Select drop-off location by number: ")) - 1
            to_location = cities_and_townships[to_location_index]

            distance = float(input("Enter distance in kilometers: "))
            ride_type = input("Enter ride type (cheap, comfort, luxury): ")

            cursor.execute("INSERT INTO rides (rider_id, from_location, to_location, distance, ride_type) VALUES (?, ?, ?, ?, ?)",
                           (1, from_location, to_location, distance, ride_type))  # Assuming rider_id is 1 for this example
            conn.commit()
            print("Ride booked successfully!")

        except (ValueError, IndexError):
            print("Invalid input. Please enter valid numbers for location and distance.")

    elif choice == '3':
        # Fare calculation (Not implemented)
        print("Fare calculation feature not implemented yet.")

    elif choice == '4':
        # Driver tipping (Not implemented)
        print("Driver tipping feature not implemented yet.")

    elif choice == '5':
        # Rate settings (Not implemented)
        print("Rate settings feature not implemented yet.")

    elif choice == '6':
        # Driver report (Not implemented)
        print("Driver report feature not implemented yet.")

    elif choice == '7':
        # Quit the program
        print("Exiting ByteRide. Goodbye!")
        conn.close()
        break

    else:
        print("Invalid choice. Please select a valid option.")

# Comments have been added to explain the code's functionality and intent.
